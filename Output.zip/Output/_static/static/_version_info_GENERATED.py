version_info = (
{
  "build_mtime": "1582644985",
  "module_name": "sphinx_typo3_theme",
  "version_scm": "4.1.3",
  "version_scm_build": "",
  "version_scm_core": "4.1.3",
  "version_scm_pre_release": ""
}
)
